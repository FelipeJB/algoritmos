1. LP
input_n#_k#
Línea 1: k
Línea 2 en adelante: Matriz de adyacencia
	Nombre del nodo + peso de cada arista conectando este nodo con todos los demás
output_n#_k#
Línea 1: Costo de la solución
Línea 2: Vertices donde se ubicara una tienda, separados por ",".

input_n#_k#_c
Línea 1: k
Línea 2 en adelante: Costo de Construir + Matriz de adyacencia
	Nombre del nodo + costo de construir una tienda en este nodo +
peso de cada arista conectando este nodo con todos los demás
output_n#_k#_c
Línea 1: Costo de la solución
Línea 2: Vertices donde se ubicara una tienda, separados por ",".

