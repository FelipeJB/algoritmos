Hello User !!!
we are glad to have you.

Our application can save 95% of your work. But it is still in BETA

However if you face any problem like:

1] PDF is not generated that means there is compilataion error.
    In this case, source code (".tex") will be provided.

    Solution: Please leave us a message and we will take care of your problem ASAP.
              We are constantly improving :D


And if you find our application helpful,leave us a positive feedback :)
http://docx2latex.pythonanywhere.com/#MES
